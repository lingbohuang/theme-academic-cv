*========================================
* Analysis - Experiment 1
*========================================
* This file generates all tables and figures for Experiment 1

set more off
cap log close
log using "$code_folder/stata/log_analysis_exp1", replace

* Load processed data
use "$exp1_processed", clear

graph set window fontface "Times New Roman"

*========================================
* MAIN TEXT TABLES AND FIGURES
*========================================

*========================================
* TABLE 2: Estimated Proportion of Types
*========================================
display "Generating TABLE 2..."

* Reload processed data
use "$exp1_processed", clear

* Calculate proportions
sum extensive if idAvoid==2 & match==0
local pure_giver = r(mean)/100

sum extensive if idAvoid==1 & match==0
local noavoid_nomatch = r(mean)/100

local reluctant = `noavoid_nomatch' - `pure_giver'
local non_giver = 1 - `noavoid_nomatch'

sum extensive if idAvoid==1 & match==1
local noavoid_match = r(mean)/100
local match_responsive = `noavoid_match' - `noavoid_nomatch'
local match_unresponsive = `non_giver' - `match_responsive'

* Create table
clear
set obs 4
gen type = ""
gen proportion = .
gen description = ""

replace type = "Pure Givers" in 1
replace proportion = `pure_giver' in 1
replace description = "Give regardless of match or avoidance" in 1

replace type = "Reluctant Givers" in 2
replace proportion = `reluctant' in 2
replace description = "Give only when match present, no avoidance" in 2

replace type = "Non-givers (match-responsive)" in 3
replace proportion = `match_responsive' in 3
replace description = "Give only with match, no avoidance" in 3

replace type = "Non-givers (match-unresponsive)" in 4
replace proportion = `match_unresponsive' in 4
replace description = "Never give" in 4

* Export to LaTeX (manual table with mathematical notation)
file open table2 using "$tables_folder/table2.tex", write replace
file write table2 "\begin{table}" _n
file write table2 "\caption{Estimated proportion of each type in Experiment 1}" _n
file write table2 "\label{tab:type_proportions}" _n
file write table2 "\centering" _n
file write table2 "\begin{tabular}{lc}" _n
file write table2 "\hline" _n
file write table2 "\hline" _n
file write table2 "Type & Proportion \\" _n
file write table2 "\hline" _n
file write table2 "Pure givers & " %5.1f (`pure_giver'*100) " \\" _n
file write table2 "Reluctant givers & " %5.1f (`reluctant'*100) " \\" _n
file write table2 "Non-givers (match-responsive) & " %5.1f (`match_responsive'*100) " \\" _n
file write table2 "Non-givers (match-unresponsive) & " %5.1f (`match_unresponsive'*100) " \\" _n
file write table2 "\hline" _n
file write table2 "\end{tabular}" _n
file write table2 "\end{table}" _n
file close table2

*========================================
* FIGURE 1: Effect of match on giving
*========================================
display "Generating FIGURE 1..."

* Reload processed data
use "$exp1_processed", clear

* Figure 1(a): Frequency of giving
preserve
collapse extensive (semean) se_c = extensive, by(idAvoid match)
gen c_u = extensive + se_c
gen c_l = extensive - se_c
gen x = 1 if idAvoid==1 & match==0
replace x = 1 if idAvoid==2 & match==0
replace x = 2 if idAvoid==1 & match==1
replace x = 2 if idAvoid==2 & match==1
gen mean_string = string(extensive, "%2.1f")
twoway (connected extensive x if idAvoid == 1, mlcolor(gs1)) ///
       (connected extensive x if idAvoid == 2, mlcolor(gs13)) ///
	   (rcap c_u c_l x, lcolor("black")) ///
	   (scatter extensive x, msym(none) mlab(mean_string) mlabsize(medium) mlabpos(11) mlabcolor(black)) ///
	   , legend(row(1) pos(12) ring(0) order(1 "No Avoid" 2 "Avoid")) ///
	   xtitle("") xlabel(0.5 " " 1 "No Match" 2 "Match" 2.5 " ", noticks) ///
	   ytitle("Frequency of giving (%)") ylabel(40(10)100, ang(0)) ///
	   ysize(4) xsize(6) scale(1.2) scheme(s1mono)
graph export "$figures_folder/figure1a.png", replace
restore

* Figure 1(b): Out-of-pocket giving
preserve
collapse checkbook (semean) se_c = checkbook, by(idAvoid match)
gen c_u = checkbook + se_c
gen c_l = checkbook - se_c
gen x = 1 if idAvoid==1 & match==0
replace x = 1 if idAvoid==2 & match==0
replace x = 2 if idAvoid==1 & match==1
replace x = 2 if idAvoid==2 & match==1
gen mean_string = string(checkbook, "%3.2f")
twoway (connected checkbook x if idAvoid == 1, mlcolor(gs1)) ///
       (connected checkbook x if idAvoid == 2, mlcolor(gs13)) ///
	   (rcap c_u c_l x, lcolor("black")) ///
	   (scatter checkbook x, msym(none) mlab(mean_string) mlabsize(medium) mlabpos(11) mlabcolor(black)) ///
	   , legend(row(1) pos(12) ring(0) order(1 "No Avoid" 2 "Avoid")) ///
	   xtitle("") xlabel(0.5 " " 1 "No Match" 2 "Match" 2.5 " ", noticks) ///
	   ytitle("Out-of-pocket giving") ylabel(2(1)6, ang(0)) ///
	   ysize(4) xsize(6) scale(1.2) scheme(s1mono)
graph export "$figures_folder/figure1b.png", replace
restore

*========================================
* APPENDIX TABLES
*========================================

*========================================
* TABLE S2: Descriptive Statistics
*========================================
display "Generating TABLE S2..."

* Reload processed data
use "$exp1_processed", clear

* Convert binary variables to percentages
replace female = female * 100
replace asian = asian * 100
replace christian = christian * 100
replace liberal = liberal * 100
replace econ = econ * 100

* Balance table
bys treatment: sum female age yearStudy asian christian liberal selfEst selfConPri selfConPub socAnx govRes charityRes selfRes freqDon freqVol econ

* Export to LaTeX - all four columns together
estpost sum female age yearStudy asian christian liberal selfEst selfConPri selfConPub socAnx govRes charityRes selfRes freqDon freqVol econ if treatment == "NoAvoidNoMatch", detail
est store S2_1

estpost sum female age yearStudy asian christian liberal selfEst selfConPri selfConPub socAnx govRes charityRes selfRes freqDon freqVol econ if treatment == "NoAvoidMatch", detail
est store S2_2

estpost sum female age yearStudy asian christian liberal selfEst selfConPri selfConPub socAnx govRes charityRes selfRes freqDon freqVol econ if treatment == "AvoidNoMatch", detail
est store S2_3

estpost sum female age yearStudy asian christian liberal selfEst selfConPri selfConPub socAnx govRes charityRes selfRes freqDon freqVol econ if treatment == "AvoidMatch", detail
est store S2_4

esttab S2_1 S2_2 S2_3 S2_4 using "$tables_folder/tableS2.tex", replace ///
    cells("mean(fmt(1)) sd(fmt(1))") ///
    title("Table S2: Descriptive statistics in Experiment 1") ///
    nonumber nomtitles ///
    collabels("No Avoid" "No Avoid" "Avoid" "Avoid" \"Mean (SD)" \"Mean (SD)" \"Mean (SD)" \"Mean (SD)") ///
    mlabels("No Match" "Match" "No Match" "Match") ///
    compress

eststo clear

*========================================
* TABLE S3: Probit Regression
*========================================
display "Generating TABLE S3..."

use "$exp1_processed", clear

* Model 1: No Avoid, no controls
probit extensive i.match if idAvoid==1, vce(cluster session)
est store m1
margins, dydx(*) post
est store m1_marg

* Model 2: No Avoid, with controls
probit extensive i.match selfEst selfConPri selfConPub socAnx govRes charityRes selfRes freqDon freqVol ///
    female age econ yearStudy asian christian liberal if idAvoid==1, vce(cluster session)
est store m2
margins, dydx(*) post
est store m2_marg

* Model 3: Avoid, no controls
probit extensive i.match if idAvoid==2, vce(cluster session)
est store m3
margins, dydx(*) post
est store m3_marg

* Model 4: Avoid, with controls
probit extensive i.match selfEst selfConPri selfConPub socAnx govRes charityRes selfRes freqDon freqVol ///
    female age econ yearStudy asian christian liberal if idAvoid==2, vce(cluster session)
est store m4
margins, dydx(*) post
est store m4_marg

* Export marginal effects only
esttab m1_marg m2_marg m3_marg m4_marg using "$tables_folder/tableS3.tex", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    nonumbers compress ///
    title("Table S3: Probit regression of frequency of giving") ///
    mtitles("No Avoid" "No Avoid" "Avoid" "Avoid") ///
    keep(1.match)

eststo clear

*========================================
* TABLE S4: Probit regression of frequency of avoiding the ask
*========================================
display "Generating TABLE S4..."

use "$exp1_processed", clear

* Model 1: No controls
probit doAvoid i.match if idAvoid==2, vce(cluster session)
est store S4_1
margins, dydx(*) post
est store S4_1_marg

* Model 2: With controls
probit doAvoid i.match selfEst selfConPri selfConPub socAnx govRes charityRes selfRes freqDon freqVol ///
    female age econ yearStudy asian christian liberal if idAvoid==2, vce(cluster session)
est store S4_2
margins, dydx(*) post
est store S4_2_marg

* Export to LaTeX
esttab S4_1_marg S4_2_marg using "$tables_folder/tableS4.tex", replace ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    nonumbers compress ///
    title("Table S4: Probit regression of frequency of avoiding the ask") ///
    mtitles("(1)" "(2)") ///
    keep(1.match)

eststo clear

*========================================
* APPENDIX FIGURES
*========================================

*========================================
* FIGURE S3: Intensive margin
*========================================
display "Generating FIGURE S3..."

use "$exp1_processed", clear

preserve
drop if checkbook == 0
collapse checkbook (semean) se_c = checkbook, by(idAvoid match)
gen c_u = checkbook + se_c
gen c_l = checkbook - se_c
gen x = 1 if idAvoid==1 & match==0
replace x = 1 if idAvoid==2 & match==0
replace x = 2 if idAvoid==1 & match==1
replace x = 2 if idAvoid==2 & match==1
gen mean_string = string(checkbook, "%3.2f")
twoway (connected checkbook x if idAvoid == 1, mlcolor(gs1)) ///
       (connected checkbook x if idAvoid == 2, mlcolor(gs13)) ///
	   (rcap c_u c_l x, lcolor("black")) ///
	   (scatter checkbook x, msym(none) mlab(mean_string) mlabsize(medium) mlabpos(11) mlabcolor(black)) ///
	   , legend(row(1) pos(12) ring(0) order(1 "No Avoid" 2 "Avoid")) ///
	   xtitle("") xlabel(0.5 " " 1 "No Match" 2 "Match" 2.5 " ", noticks) ///
	   ytitle("Giving on intensive margin") ylabel(2(1)8, ang(0)) ///
	   ysize(4) xsize(6) scale(1.2) scheme(s1mono)
graph export "$figures_folder/figureS3.png", replace
restore

*========================================
* FIGURE S4: Distribution of giving
*========================================
display "Generating FIGURE S4..."

use "$exp1_processed", clear

preserve
gen checkbook2 = checkbook
collapse (count) checkbook2, by(match idAvoid checkbook)
bys match idAvoid: egen sum = sum(checkbook2)
gen _percent = 100 * checkbook2 / sum
replace checkbook = checkbook - 0.2 if match == 0
replace checkbook = checkbook + 0.2 if match == 1
twoway (bar _percent checkbook if match==0 & idAvoid==1, barw(0.4) color(gs7)) ///
       (bar _percent checkbook if match==1 & idAvoid==1, barw(0.4) fcolor(none) lcolor(black)), ///
	   legend(row(1) pos(12) ring(0) order(1 "No Match" 2 "Match") ) scheme(s1mono) xtitle("") title("No Avoid") ylabel(0(10)40, ang(0)) ytitle(Percent)
graph save "$figures_folder/figureS4_noavoid.gph", replace
twoway (bar _percent checkbook if match==0 & idAvoid==2, barw(0.4) color(gs7)) ///
       (bar _percent checkbook if match==1 & idAvoid==2, barw(0.4) fcolor(none) lcolor(black)), ///
	   legend(off) scheme(s1mono) xtitle("Checkbook giving") title("Avoid") ///
	   ylabel(0(10)40, ang(0)) ytitle(Percent)
graph save "$figures_folder/figureS4_avoid.gph", replace
graph combine "$figures_folder/figureS4_noavoid.gph" "$figures_folder/figureS4_avoid.gph" , ///
scheme(s1mono) rows(2)  xsize(1) ysize(1) scale(1) ycommon
graph export "$figures_folder/figureS4.png", replace

* Remove temporary gph files
rm "$figures_folder/figureS4_noavoid.gph"
rm "$figures_folder/figureS4_avoid.gph"

restore

*========================================
* Statistical Tests Summary
*========================================
display "Generating statistical tests..."

use "$exp1_processed", clear

* Manuscript reports Fisher's exact tests for frequency of giving

* Test 1: No Avoid - Match effect on frequency of giving
* Reported: p=0.015 (67.3% vs 82.8%)
tab extensive2 treatment if treatment=="NoAvoidMatch"|treatment=="NoAvoidNoMatch", exact

* Test 2: Avoid - Match effect on frequency of giving
* Reported: p=1.000 (59.1% vs 60.0%)
tab extensive2 treatment if treatment=="AvoidMatch"|treatment=="AvoidNoMatch", exact

* Test 3: Avoid frequency - Match vs No Match
* Reported: p=0.661 (38.2% vs 34.4%)
tab doAvoid treatment if treatment=="AvoidMatch"|treatment=="AvoidNoMatch", exact

* Test 4: Wilcoxon rank-sum test - out-of-pocket giving (No Avoid)
* Reported: p=0.064 ($3.69 vs $4.77)
ranksum checkbook if idAvoid==1, by(match)

* Test 5: Wilcoxon rank-sum test - out-of-pocket giving (Avoid)
* Reported: p=0.859 ($2.83 vs $3.06)
ranksum checkbook if idAvoid==2, by(match)

* Test 6: Balance check - multinomial logit
* Reported: p=0.316 (joint orthogonality test)
* Run mlogit with treatment as dependent variable
mlogit treat female age econ yearStudy asian christian liberal selfEst selfConPri selfConPub socAnx govRes charityRes selfRes freqDon freqVol
test female=age=econ=yearStudy=asian=christian=liberal=selfEst=selfConPri=selfConPub=socAnx=govRes=charityRes=selfRes=freqDon=freqVol=0

log close

display "Analysis complete. All outputs saved to:"
display "  Tables: $tables_folder"
display "  Figures: $figures_folder"
