* Replication Package Setup File
* This file sets up global paths and installs required packages
* Modify the folder path below to match your system

* Get the directory where this file is located
global folder "/path/to/your/replication_package/paper"

* Display current working directory
display "Replication package folder: $folder"

* Install required packages
*capture ssc install estout, replace

* Set up additional paths
global data_folder "$folder/data"
global code_folder "$folder/code"
global output_folder "$folder/output"
global figures_folder "$output_folder/figures"
global tables_folder "$output_folder/tables"

* Set up data file paths
global exp1_raw "$data_folder/raw/exp1_raw.dta"
global exp2_raw "$data_folder/raw/exp2_raw.dta"
global exp1_processed "$data_folder/processed/exp1_processed.dta"
global exp2_processed "$data_folder/processed/exp2_processed.dta"

display "Paths configured successfully"
display "Data folder: $data_folder"
display "Code folder: $code_folder"
display "Output folder: $output_folder"
display ""
display "To run all analysis:"
display "do "$code_folder/stata/1Master.do""
