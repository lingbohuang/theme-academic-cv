*========================================
* Data Cleaning - Experiment 1
*========================================
* Load raw data and create processed dataset

use "$exp1_raw", clear

* Create variable labels and recode variables

* Approval questions (desirability)
foreach num of numlist 1/7 {
    gen appro`num' = 1 if d`num' == "Extremely undesirable"
    replace appro`num' = 2 if d`num' == "Moderately undesirable"
    replace appro`num' = 3 if d`num' == "Slightly undesirable"
    replace appro`num' = 4 if d`num' == "Neither desirable nor undesirable"
    replace appro`num' = 5 if d`num' == "Slightly desirable"
    replace appro`num' = 6 if d`num' == "Moderately desirable"
    replace appro`num' = 7 if d`num' == "Extremely desirable"
}

foreach num of numlist 1/7 {
    gen approCutoff`num' = -1 if appro`num' < 4
    replace approCutoff`num' = 0 if appro`num' == 4
    replace approCutoff`num' = 1 if appro`num' > 4
}

* Norm questions
foreach num of numlist 1/7 {
    gen norm`num' = 1 if n`num' == "Extremely undesirable"
    replace norm`num' = 2 if n`num' == "Moderately undesirable"
    replace norm`num' = 3 if n`num' == "Slightly undesirable"
    replace norm`num' = 4 if n`num' == "Neither desirable nor undesirable"
    replace norm`num' = 5 if n`num' == "Slightly desirable"
    replace norm`num' = 6 if n`num' == "Moderately desirable"
    replace norm`num' = 7 if n`num' == "Extremely desirable"
}

foreach num of numlist 1/7 {
    gen normCutoff`num' = -1 if norm`num' < 4
    replace normCutoff`num' = 0 if norm`num' == 4
    replace normCutoff`num' = 1 if norm`num' > 4
}

* Self-esteem scale
foreach num of numlist 1/10 {
    gen selfEst`num' = 1 if se`num' == "Strongly Agree"
    replace selfEst`num' = 2 if se`num' == "Agree Somewhat"
    replace selfEst`num' = 3 if se`num' == "Disagree Somewhat"
    replace selfEst`num' = 4 if se`num' == "Strongly Disagree"
}
replace selfEst3 = 5 - selfEst3
replace selfEst5 = 5 - selfEst5
replace selfEst8 = 5 - selfEst8
replace selfEst9 = 5 - selfEst9
replace selfEst10 = 5 - selfEst10

gen selfEst = 0
foreach num of numlist 1/10 {
    replace selfEst = selfEst + selfEst`num'
}

* Social connection scale
foreach num of numlist 1/22 {
    gen selfCon`num' = 3 if sc`num' == "a lot like me"
    replace selfCon`num' = 2 if sc`num' == "somwhat like me"
    replace selfCon`num' = 1 if sc`num' == "a little like me"
    replace selfCon`num' = 0 if sc`num' == "not like me at all"
}
replace selfCon8 = 3 - selfCon8
replace selfCon9 = 3 - selfCon9
replace selfCon10 = 3 - selfCon10
replace selfCon11 = 3 - selfCon11

gen selfConPri = selfCon1 + selfCon4 + selfCon6 + selfCon8 + selfCon12 + selfCon14 + selfCon17 + selfCon19 + selfCon21
gen selfConPub = selfCon2 + selfCon5 + selfCon10 + selfCon13 + selfCon16 + selfCon18 + selfCon20
gen socAnx = selfCon3 + selfCon7 + selfCon9 + selfCon11 + selfCon15 + selfCon22

* Government responsibility
gen govRes = 1 if govResp == "Strongly agree"
replace govRes = 2 if govResp == "Agree"
replace govRes = 3 if govResp == "Somewhat agree"
replace govRes = 4 if govResp == "Neither agree nor disagree"
replace govRes = 5 if govResp == "Somewhat disagree"
replace govRes = 6 if govResp == "Disagree"
replace govRes = 7 if govResp == "Strongly disagree"
gen govRes1 = (govRes < 4)

* Charity responsibility
gen charityRes = 1 if CharityResp == "Strongly agree"
replace charityRes = 2 if CharityResp == "Agree"
replace charityRes = 3 if CharityResp == "Somewhat agree"
replace charityRes = 4 if CharityResp == "Neither agree nor disagree"
replace charityRes = 5 if CharityResp == "Somewhat disagree"
replace charityRes = 6 if CharityResp == "Disagree"
replace charityRes = 7 if CharityResp == "Strongly disagree"
gen charityRes1 = (charityRes < 4)

* Self responsibility
gen selfRes = 1 if selfResp == "Strongly agree"
replace selfRes = 2 if selfResp == "Agree"
replace selfRes = 3 if selfResp == "Somewhat agree"
replace selfRes = 4 if selfResp == "Neither agree nor disagree"
replace selfRes = 5 if selfResp == "Somewhat disagree"
replace selfRes = 6 if selfResp == "Disagree"
replace selfRes = 7 if selfResp == "Strongly disagree"
gen selfRes1 = (selfRes < 4)

* Frequency of donation
gen freqDon = 1 if freqDonation == "Not at all"
replace freqDon = 2 if freqDonation == "Once"
replace freqDon = 3 if freqDonation == "2 or 3 times"
replace freqDon = 4 if freqDonation == "4 or 5 times"
replace freqDon = 5 if freqDonation == "More than 5 times"
gen freqDon1 = (freqDon <= 2)

* Frequency of volunteering
gen freqVol = 1 if freqVolunteer == "Not at all"
replace freqVol = 2 if freqVolunteer == "Once"
replace freqVol = 3 if freqVolunteer == "2 or 3 times"
replace freqVol = 4 if freqVolunteer == "4 or 5 times"
replace freqVol = 5 if freqVolunteer == "More than 5 times"
gen freqVol1 = (freqVol <= 2)

* Big five personality traits
foreach num of numlist 1/10 {
    gen bff`num' = 1 if bf`num' == "Strongly agree"
    replace bff`num' = 2 if bf`num' == "Agree"
    replace bff`num' = 3 if bf`num' == "Somewhat agree"
    replace bff`num' = 4 if bf`num' == "Neither agree nor disagree"
    replace bff`num' = 5 if bf`num' == "Somewhat disagree"
    replace bff`num' = 6 if bf`num' == "Disagree"
    replace bff`num' = 7 if bf`num' == "Strongly disagree"
}

rename bff1 reserved
rename bff2 trusting
rename bff3 lazy
rename bff4 relaxed
rename bff5 nonartist
rename bff6 sociable
rename bff7 fault
rename bff8 thorough
rename bff9 nervous
rename bff10 imagination

* Demographics
gen female = (male == "Female")

gen field = 1 if study == "Art, Design and Architecture"
replace field = 2 if study == "Business and Economics"
replace field = 3 if study == "Engineering"
replace field = 4 if study == "Law"
replace field = 5 if study == "Pharmacy and Pharmaceutical Sciences"
replace field = 6 if study == "Arts"
replace field = 7 if study == "Education"
replace field = 8 if study == "Information Technology"
replace field = 9 if study == "Medicine, Nursing and Health Sciences"
replace field = 10 if study == "Sciences"
gen econ = (field == 2)

gen yearStudy = 1 if year == "First Year"
replace yearStudy = 2 if year == "Second Year"
replace yearStudy = 3 if year == "Third Year"
replace yearStudy = 4 if year == "Fourth Year / Honours"
replace yearStudy = 5 if year == "Graduate Student"

gen ethnics = 1 if ethics == "Oceanian"
replace ethnics = 2 if ethics == "North-West European"
replace ethnics = 3 if ethics == "Southern and Eastern European"
replace ethnics = 4 if ethics == "North African and Middle Eastern"
replace ethnics = 5 if ethics == "South-East Asian"
replace ethnics = 6 if ethics == "North-East Asian"
replace ethnics = 7 if ethics == "Southern and Central Asian"
replace ethnics = 8 if ethics == "Peoples of the Americas"
replace ethnics = 9 if ethics == "Sub-Saharan African"
gen asian = (ethnics >= 5 & ethnics <= 7)

gen religions = 1 if religion == "Christian"
replace religions = 2 if religion == "Buddhist"
replace religions = 3 if religion == "Muslim"
replace religions = 4 if religion == "Jewish"
replace religions = 5 if religion == "Hindu"
replace religions = 6 if religion == "Other"
replace religions = 7 if religion == "None"
gen christian = (religions == 1)

gen politParty = 1 if party == "Greens"
replace politParty = 2 if party == "Labour"
replace politParty = 3 if party == "Liberal / National"
replace politParty = 4 if party == "Other"
gen liberal = (politParty == 3)

* Main outcome variable
gen extensive = (checkbook>0)*100
gen extensive2 = (checkbook>0)

* Treatment variables (already in raw data: match and idAvoid)
egen treat = group(treatment)

* Drop unused string variables
drop avoid knowSalvo otherCharity d1-d7 n1-n7 se1-se10 sc1-sc22
drop govResp CharityResp selfResp freqDonation freqVolunteer bf1-bf10
drop male study year ethics religion party

* Save processed data
save "$exp1_processed", replace

display "Data cleaning complete: exp1_processed.dta saved"
