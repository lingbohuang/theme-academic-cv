*========================================
* Analysis - Experiment 2
*========================================
* This file generates all tables and figures for Experiment 2

set more off
cap log close
log using "$code_folder/stata/log_analysis_exp2", replace

* Load processed data
use "$exp2_processed", clear

graph set window fontface "Times New Roman"

*========================================
* TABLE 3: Normative Beliefs
*========================================
display "Generating TABLE 3..."

use "$exp2_processed", clear

* Prepare data for normative beliefs table
preserve
rename norm11 skip_nomatch
rename norm12 zero_nomatch
rename norm21 skip_match
rename norm22 zero_match

gen oneormore_nomatch = (norm13 + norm14 + norm15 + norm16 + norm17)/5
gen oneormore_match = (norm23 + norm24 + norm25 + norm26 + norm27)/5

replace skip_nomatch = 0 if skip_nomatch==.
replace skip_match = 0 if skip_match==.

* Helper program to calculate mean and se by avoid group
cap program drop mean_se_by_avoid
program define mean_se_by_avoid, rclass
    syntax varlist(min=1 max=1)
    local var1 : word 1 of `varlist'

    sum `var1' if avoid == 0
    return scalar mean_noavoid = r(mean)
    return scalar se_noavoid = r(sd)/sqrt(r(N))

    sum `var1' if avoid == 1
    return scalar mean_avoid = r(mean)
    return scalar se_avoid = r(sd)/sqrt(r(N))
end

* Helper program to get Wilcoxon p-value
cap program drop wilcoxon_p_by_avoid
program define wilcoxon_p_by_avoid, rclass
    syntax varlist(min=2 max=2)
    local var1 : word 1 of `varlist'
    local var2 : word 2 of `varlist'

    signrank `var1' = `var2' if avoid == 0
    return scalar p_noavoid = r(p)

    signrank `var1' = `var2' if avoid == 1
    return scalar p_avoid = r(p)
end

* Calculate statistics
mean_se_by_avoid skip_nomatch
scalar skip_nomatch_mean_avoid = r(mean_avoid)
scalar skip_nomatch_se_avoid = r(se_avoid)

mean_se_by_avoid skip_match
scalar skip_match_mean_avoid = r(mean_avoid)
scalar skip_match_se_avoid = r(se_avoid)

wilcoxon_p_by_avoid skip_nomatch skip_match
scalar p_skip_noavoid = r(p_noavoid)
scalar p_skip_avoid = r(p_avoid)

mean_se_by_avoid zero_nomatch
scalar zero_nomatch_mean_noavoid = r(mean_noavoid)
scalar zero_nomatch_se_noavoid = r(se_noavoid)
scalar zero_nomatch_mean_avoid = r(mean_avoid)
scalar zero_nomatch_se_avoid = r(se_avoid)

mean_se_by_avoid zero_match
scalar zero_match_mean_noavoid = r(mean_noavoid)
scalar zero_match_se_noavoid = r(se_noavoid)
scalar zero_match_mean_avoid = r(mean_avoid)
scalar zero_match_se_avoid = r(se_avoid)

wilcoxon_p_by_avoid zero_nomatch zero_match
scalar p_zero_noavoid = r(p_noavoid)
scalar p_zero_avoid = r(p_avoid)

mean_se_by_avoid oneormore_nomatch
scalar oneormore_nomatch_mean_noavoid = r(mean_noavoid)
scalar oneormore_nomatch_se_noavoid = r(se_noavoid)
scalar oneormore_nomatch_mean_avoid = r(mean_avoid)
scalar oneormore_nomatch_se_avoid = r(se_avoid)

mean_se_by_avoid oneormore_match
scalar oneormore_match_mean_noavoid = r(mean_noavoid)
scalar oneormore_match_se_noavoid = r(se_noavoid)
scalar oneormore_match_mean_avoid = r(mean_avoid)
scalar oneormore_match_se_avoid = r(se_avoid)

wilcoxon_p_by_avoid oneormore_nomatch oneormore_match
scalar p_oneormore_noavoid = r(p_noavoid)
scalar p_oneormore_avoid = r(p_avoid)

* Print table
di as text _newline(1)
di as txt "---------------------------------------------------------------"
di as txt "                      No Avoid                     Avoid"
di as txt "             Mean       Wilcoxon       Mean       Wilcoxon"
di as txt "Donation    (Std.Err.)   signed-rank  (Std.Err.)   signed-rank"
di as txt "            NoMatch  Match    p-value  NoMatch  Match    p-value"
di as txt "---------------------------------------------------------------"

di "Skip       -        -        -        " ///
   %5.2f skip_nomatch_mean_avoid " (" %4.2f skip_nomatch_se_avoid ")  " ///
   %5.2f skip_match_mean_avoid " (" %4.2f skip_match_se_avoid ")  " ///
   %5.3f p_skip_avoid

di " $0        " ///
   %5.2f zero_nomatch_mean_noavoid " (" %4.2f zero_nomatch_se_noavoid ")  " ///
   %5.2f zero_match_mean_noavoid " (" %4.2f zero_match_se_noavoid ")  " ///
   %5.3f p_zero_noavoid "   " ///
   %5.2f zero_nomatch_mean_avoid " (" %4.2f zero_nomatch_se_avoid ")  " ///
   %5.2f zero_match_mean_avoid " (" %4.2f zero_match_se_avoid ")  " ///
   %5.3f p_zero_avoid

di " $1 or more " ///
   %5.2f oneormore_nomatch_mean_noavoid " (" %4.2f oneormore_nomatch_se_noavoid ")  " ///
   %5.2f oneormore_match_mean_noavoid " (" %4.2f oneormore_match_se_noavoid ")  " ///
   %5.3f p_oneormore_noavoid "   " ///
   %5.2f oneormore_nomatch_mean_avoid " (" %4.2f oneormore_nomatch_se_avoid ")  " ///
   %5.2f oneormore_match_mean_avoid " (" %4.2f oneormore_match_se_avoid ")  " ///
   %5.3f p_oneormore_avoid

di "---------------------------------------------------------------"

* Export to LaTeX (manual table)
cap file close table3
file open table3 using "$tables_folder/table3.tex", write replace
file write table3 "\begin{table}" _n
file write table3 "\caption{Normative belief about social desirability of giving behaviour}" _n
file write table3 "\label{tab:normative_beliefs}" _n
file write table3 "\centering" _n
file write table3 "\begin{tabular}{lccccccc}" _n
file write table3 "\hline" _n
file write table3 "\hline" _n
file write table3 "& \multicolumn{3}{c}{No Avoid} & \multicolumn{3}{c}{Avoid} \\" _n
file write table3 "\cline{2-4} \cline{5-7}" _n
file write table3 "Donation & \multicolumn{1}{c}{Mean} & \multicolumn{1}{c}{Mean} & \multicolumn{1}{c}{Wilcoxon} & \multicolumn{1}{c}{Mean} & \multicolumn{1}{c}{Mean} & \multicolumn{1}{c}{Wilcoxon} \\" _n
file write table3 "& \multicolumn{1}{c}{NoMatch} & \multicolumn{1}{c}{Match} & \multicolumn{1}{c}{signed-rank} & \multicolumn{1}{c}{NoMatch} & \multicolumn{1}{c}{Match} & \multicolumn{1}{c}{signed-rank} \\" _n
file write table3 "& \multicolumn{1}{c}{(Std.Err.)} & \multicolumn{1}{c}{(Std.Err.)} & \multicolumn{1}{c}{p-value} & \multicolumn{1}{c}{(Std.Err.)} & \multicolumn{1}{c}{(Std.Err.)} & \multicolumn{1}{c}{p-value} \\" _n
file write table3 "\hline" _n
local skip1 = string(skip_nomatch_mean_avoid, "%5.2f")
local skip1_se = string(skip_nomatch_se_avoid, "%4.2f")
local skip2 = string(skip_match_mean_avoid, "%5.2f")
local skip2_se = string(skip_match_se_avoid, "%4.2f")
local p_skip = string(p_skip_avoid, "%5.3f")
file write table3 "Skip & - & - & - & `skip1' (`skip1_se') & `skip2' (`skip2_se') & `p_skip' \\" _n
local z1 = string(zero_nomatch_mean_noavoid, "%5.2f")
local z1_se = string(zero_nomatch_se_noavoid, "%4.2f")
local z2 = string(zero_match_mean_noavoid, "%5.2f")
local z2_se = string(zero_match_se_noavoid, "%4.2f")
local p_z = string(p_zero_noavoid, "%5.3f")
local z3 = string(zero_nomatch_mean_avoid, "%5.2f")
local z3_se = string(zero_nomatch_se_avoid, "%4.2f")
local z4 = string(zero_match_mean_avoid, "%5.2f")
local z4_se = string(zero_match_se_avoid, "%4.2f")
local p_z2 = string(p_zero_avoid, "%5.3f")
file write table3 "$0 & `z1' (`z1_se') & `z2' (`z2_se') & `p_z' & `z3' (`z3_se') & `z4' (`z4_se') & `p_z2' \\" _n
local o1 = string(oneormore_nomatch_mean_noavoid, "%5.2f")
local o1_se = string(oneormore_nomatch_se_noavoid, "%4.2f")
local o2 = string(oneormore_match_mean_noavoid, "%5.2f")
local o2_se = string(oneormore_match_se_noavoid, "%4.2f")
local p_o = string(p_oneormore_noavoid, "%5.3f")
local o3 = string(oneormore_nomatch_mean_avoid, "%5.2f")
local o3_se = string(oneormore_nomatch_se_avoid, "%4.2f")
local o4 = string(oneormore_match_mean_avoid, "%5.2f")
local o4_se = string(oneormore_match_se_avoid, "%4.2f")
local p_o2 = string(p_oneormore_avoid, "%5.3f")
file write table3 "$1 or more & `o1' (`o1_se') & `o2' (`o2_se') & `p_o' & `o3' (`o3_se') & `o4' (`o4_se') & `p_o2' \\" _n
file write table3 "\hline" _n
file write table3 "\end{tabular}" _n
file write table3 "\end{table}" _n
file close table3
restore

*========================================
* TABLE S5: Descriptive Statistics
*========================================
display "Generating TABLE S5..."

use "$exp2_processed", clear

* Convert binary variables to percentages
replace female = female * 100
replace asian = asian * 100
replace christian = christian * 100
replace liberal = liberal * 100
replace econ = econ * 100

bys avoid: sum female age1 yearStudy asian christian liberal govRes charityRes selfRes freqDon freqVol econ

* Export to LaTeX - single combined table
estpost sum female age1 yearStudy asian christian liberal govRes charityRes selfRes freqDon freqVol econ if avoid == 0, detail
est store S5_1

estpost sum female age1 yearStudy asian christian liberal govRes charityRes selfRes freqDon freqVol econ if avoid == 1, detail
est store S5_2

esttab S5_1 S5_2 using "$tables_folder/tableS5.tex", replace ///
    cells("mean(fmt(1)) sd(fmt(1))") ///
    title("Table S5: Descriptive statistics in Experiment 2") ///
    nonumber nomtitles ///
    collabels("No Avoid" "Avoid") ///
    mlabels("Mean (SD)" "Mean (SD)") ///
    compress

eststo clear

*========================================
* Additional Statistical Tests for Experiment 2
*========================================
display "Generating additional statistical tests..."

* Reload processed data
use "$exp2_processed", clear

* Test 1: Balance check - multinomial logit (joint orthogonality test)
* Reported: p=0.350
mlogit treat female age1 econ yearStudy asian christian liberal govRes charityRes selfRes freqDon freqVol
test female=age1=econ=yearStudy=asian=christian=liberal=govRes=charityRes=selfRes=freqDon=freqVol=0

* Test 2: Wilcoxon signed-rank test - giving is more socially desirable than not giving
* Reported: p<0.001 (pooled result)
* Compare each participant's rating for giving ($1 or more) vs $0
gen norm1_plus = (norm13 + norm14 + norm15 + norm16 + norm17)/5
gen norm2_plus = (norm23 + norm24 + norm25 + norm26 + norm27)/5
gen giving_pooled = (norm1_plus + norm2_plus) / 2
gen notgiving_pooled = (norm12 + norm22) / 2
signrank giving_pooled = notgiving_pooled

* Test 3: P3 - Skip vs $0 in Avoid condition (No Match)
* Reported: p=0.027 (3.36 vs 2.92)
signrank norm11 = norm12 if avoid == 1

* Test 4: P3 - Skip vs $0 in Avoid condition (Match)
* Reported: p=0.006 (3.27 vs 2.81)
signrank norm21 = norm22 if avoid == 1

log close

display "Analysis complete. All outputs saved to:"
display "  Tables: $tables_folder"
display "  Figures: $figures_folder"
