# README for "Preventive War" Experiment Replication Package

## Overview

This replication package contains all materials needed to reproduce the experimental analysis for "Preventive War." The study uses laboratory experiments to examine decision-making in preventive war scenarios through multiple treatment conditions.

The package includes:
- **Raw experimental data**: z-Tree session outputs (28 sessions across 7 treatments)
- **Analysis code**: Stata do-files for data cleaning, figure generation, and regression analysis
- **Experimental software**: z-Tree program files (.ztt) for all treatment conditions
- **Manuscript**: Main paper and appendix

## Data Availability

### Data Sources

**Experimental Data:**
- `data/raw/`: Original z-Tree session exports in Excel format (.xls)
  - 28 session files from November 2020 to October 2021
  - File naming convention: `YYMMDD_HHMM.xls` (e.g., `201124_1315.xls`)
  - Each session contains subject-level decisions, allocations, and outcomes

**Treatments:**
1. **PreventiveWar** (4 sessions): Baseline preventive war treatment
2. **NoWar** (4 sessions): Control condition with no war option
3. **RPCommit** (4 sessions): Rejection promise commitment treatment
4. **Chat** (4 sessions): Communication treatment
5. **Repeat** (4 sessions): Repeated interaction treatment
6. **HighCost** (2 sessions): High-cost condition
7. **LowCost** (2 sessions): Low-cost condition

### Statement about Rights

- [x] I certify that the author(s) of the manuscript have legitimate access to and permission to use the data used in this manuscript.
- [x] I certify that the author(s) of the manuscript have documented permission to redistribute/publish the data contained within this replication package.

### Summary of Availability

- [x] All data **are** publicly available in this replication package.

## Computational Requirements

### Software Requirements

**Stata** (version 15 or higher recommended)
- Required packages:
  - `ztree2stata`: For importing z-Tree data files (install from SSC)
  - `estout`: For exporting tables (install from SSC)

The file `code/0PathSetup.do` will automatically install these packages when run.

### Hardware and Runtime

**Approximate runtime:**
- Data cleaning: < 5 minutes
- Analysis (tables and figures): < 5 minutes

**Storage requirements:** < 50 MB

## Description of Programs

### Code Organization

**Setup and Path Configuration:**
- `code/0PathSetup.do`:
  - Sets all global paths for the project (EDIT THIS FILE FIRST!)
  - Installs required Stata packages
  - Creates output directories
  - **RUN THIS FILE FIRST** before any other analysis

**Data Cleaning:**
- `code/1DataClean.do`:
  - Imports raw z-Tree Excel files into Stata format
  - Merges all 28 sessions into a single dataset
  - Creates treatment indicators and variable recoding
  - Generates the main analysis dataset (`data.dta`)
  - **Run after 0PathSetup.do**

**Tables and Figures Generation:**
- `code/2Analysis.do`:
  - Generates all tables for the manuscript
  - Generates all figures for the manuscript
  - Outputs to `output/tables/` and `output/figures/`
  - **Run after 1DataClean.do**

### Program Execution Order

```stata
1. do code/0PathSetup.do      // Set up paths and install packages
2. do code/1DataClean.do       // Clean and prepare data
3. do code/2Analysis.do        // Generate all tables and figures
```

## Instructions to Replicators

### Step-by-Step Instructions

1. **Download and extract** the replication package to your local machine

2. **Open Stata** and navigate to the package root directory

3. **Edit the folder path** in `code/0PathSetup.do`:
   ```stata
   * Modify this line to match your system:
   global folder "/path/to/paper"
   ```

4. **Run the setup file**:
   ```stata
   do code/0PathSetup.do
   ```
   This will install required packages and set up global paths.

5. **Run the data cleaning**:
   ```stata
   do code/1DataClean.do
   ```
   This creates the main analysis dataset.

6. **Generate all tables and figures**:
   ```stata
   do code/2Analysis.do
   ```
   All outputs will be saved in `output/tables/` and `output/figures/`

### Expected Outputs

**Data files:**
- `data/derived/fromZtree.dta`: Raw z-Tree data combined
- `data/derived/data.dta`: Main analysis dataset

**Tables:**
- `output/tables/table2.tex`: PreventiveWar vs NoWar
- `output/tables/table3.tex`: PreventiveWar vs RPCommit
- `output/tables/table4.tex`: Cost treatments (HighCost vs LowCost)
- `output/tables/table5.tex`: Communication treatments (Chat vs Repeat)
- `output/tables/tableB1.tex`: Appendix - Profit regressions (PW vs NW & RP)
- `output/tables/tableB2.tex`: Appendix - Profit in cost treatments
- `output/tables/tableB3.tex`: Appendix - Profit in communication treatments
- `output/tables/tableB4.tex`: Appendix - Previous wars predict current war

**Figures (PNG format):**
- `output/figures/figure3.png`: Fighting rates (PreventiveWar vs NoWar)
- `output/figures/figure4.png`: Offers over time
- `output/figures/figure5.png`: Payoffs by treatment (main treatments)
- `output/figures/figure7.png`: Fighting rates (HighCost vs LowCost)
- `output/figures/figure8.png`: Fighting rates (Chat vs Repeat)

**Appendix Figures (PNG format):**
- `output/figures/figureB1.png`: Rejection by period - main treatments
- `output/figures/figureB2.png`: Conditional rejection - PreventiveWar vs NoWar
- `output/figures/figureB3.png`: Conditional rejection - RP-Commit
- `output/figures/figureB4.png`: Rejection by period - cost treatments
- `output/figures/figureB5.png`: Offers over time - cost treatments
- `output/figures/figureB6.png`: Conditional rejection - cost treatments
- `output/figures/figureB7.png`: Payoffs - cost treatments
- `output/figures/figureB8.png`: Rejection by period - communication treatments
- `output/figures/figureB9.png`: Offers over time - communication treatments
- `output/figures/figureB10.png`: Conditional rejection - communication treatments
- `output/figures/figureB11.png`: Payoffs - communication treatments

## List of Tables and Figures

### Tables in Manuscript

| Table | Program | Output file | Description |
|-------|---------|-------------|-------------|
| Table 1 | N/A | N/A | Experimental design (in manuscript) |
| Table 2 | `2Analysis.do` | `table2.tex` | PreventiveWar vs NoWar |
| Table 3 | `2Analysis.do` | `table3.tex` | PreventiveWar vs RPCommit |
| Table 4 | `2Analysis.do` | `table4.tex` | Cost treatments (HighCost vs LowCost) |
| Table 5 | `2Analysis.do` | `table5.tex` | Communication treatments (Chat vs Repeat) |

### Figures in Manuscript

| Figure | Program | Output file | Description |
|--------|---------|-------------|-------------|
| Figure 1 | N/A | N/A | Game tree (theoretical) |
| Figure 2 | N/A | N/A | Parameterization (theoretical) |
| Figure 3 | `2Analysis.do` | `figure3.png` | Fighting rates (PreventiveWar vs NoWar) |
| Figure 4 | `2Analysis.do` | `figure4.png` | Offers over time |
| Figure 5 | `2Analysis.do` | `figure5.png` | Payoffs by treatment |
| Figure 6 | N/A | N/A | Parameterization (theoretical) |
| Figure 7 | `2Analysis.do` | `figure7.png` | Fighting rates (HighCost vs LowCost) |
| Figure 8 | `2Analysis.do` | `figure8.png` | Fighting rates (Chat vs Repeat) |

### Appendix Tables

| Table | Program | Output file | Description |
|-------|---------|-------------|-------------|
| Table B1 | `2Analysis.do` | `tableB1.tex` | Profit regressions (PW vs NW & RP) |
| Table B2 | `2Analysis.do` | `tableB2.tex` | Profit in cost treatments |
| Table B3 | `2Analysis.do` | `tableB3.tex` | Profit in communication treatments |
| Table B4 | `2Analysis.do` | `tableB4.tex` | Previous wars predict current war |

### Appendix Figures

| Figure | Program | Output file | Description |
|--------|---------|-------------|-------------|
| Figure B1 | `2Analysis.do` | `figureB1.png` | Rejection by period - main treatments |
| Figure B2 | `2Analysis.do` | `figureB2.png` | Conditional rejection - PW vs NW |
| Figure B3 | `2Analysis.do` | `figureB3.png` | Conditional rejection - RP-Commit |
| Figure B4 | `2Analysis.do` | `figureB4.png` | Rejection by period - cost treatments |
| Figure B5 | `2Analysis.do` | `figureB5.png` | Offers over time - cost treatments |
| Figure B6 | `2Analysis.do` | `figureB6.png` | Conditional rejection - cost treatments |
| Figure B7 | `2Analysis.do` | `figureB7.png` | Payoffs - cost treatments |
| Figure B8 | `2Analysis.do` | `figureB8.png` | Rejection by period - comm treatments |
| Figure B9 | `2Analysis.do` | `figureB9.png` | Offers over time - comm treatments |
| Figure B10 | `2Analysis.do` | `figureB10.png` | Conditional rejection - comm treatments |
| Figure B11 | `2Analysis.do` | `figureB11.png` | Payoffs - comm treatments |

## Data Dictionary

### Key Variables

- `treatment`: Treatment indicator
  - `"1PreventiveWar"`: Baseline preventive war treatment
  - `"2NoWar"`: No war control condition
  - `"3RPCommit"`: Rejection promise commitment
  - `"5Chat"`: Communication allowed
  - `"6Repeat"`: Repeated interaction
  - `"7HighCost"`: High war cost
  - `"8LowCost"`: Low war cost

- `period`: Decision period (1-4 or 1-6 depending on session)

- `pid`: Unique subject identifier within session

- `groupid`: Group identifier within session

- `mgroup`: Matching group identifier (for Repeat treatment)

- `playerB`: Player type indicator
  - 0: Player A (the proposer)
  - 1: Player B (the responder)

- `allo1a`, `allo1b`: Allocations made by Player A in Stage 1
- `allo2a`, `allo2b`: Allocations made by Player A in Stage 2
- `allo2b_anounce`: Announcement of Stage 2 allocation

- `profit`: Player's payoff in the period

- `reject1`: Binary outcome variable
  - 1: Player B rejected/fought
  - 0: Player B accepted

### Session Identifiers

Sessions are named with format `YYMMDD_HHMM` indicating date and start time.

## Experimental Materials

### Software Files

All experimental software is in `experimental-materials/software/`:

- `PreventiveWar.ztt`: Baseline preventive war treatment
- `NoWar.ztt`: No war control condition
- `RPCommit.ztt`: Rejection promise commitment treatment
- `Chat.ztt`: Communication treatment
- `Repeat.ztt`: Repeated interaction treatment
- `HighCost.ztt`: High-cost treatment
- `LowCost.ztt`: Low-cost treatment

These `.ztt` files can be opened and modified in z-Tree.

### Raw Session Outputs

Complete z-Tree session outputs are in `experimental-materials/raw-output-from-ztree/`, organized by treatment:

```
raw-output-from-ztree/
├── PreventiveWar/
├── NoWar/
├── RPCommit/
├── Chat/
├── Repeat/
├── HighCost/
└── LowCost/
```

Each session folder contains:
- `.sbj` file: Session configuration
- `.xls` file: Raw subject-level data
- `.ztt` file: z-Tree program used
- `@db.txt`, `@lastclt.txt`: z-Tree system files

## Troubleshooting

### Common Issues

**Issue:** "file not found" error when running `1DataClean.do`
- **Solution:** Make sure you've run `0PathSetup.do` first and edited the folder path correctly

**Issue:** "command ztree2stata not recognized"
- **Solution:** Run `0PathSetup.do` to install the required package

**Issue:** "No room to add more observations" error
- **Solution:** This is normal if some data files already exist. The code handles this with `capture` commands.

**Issue:** Tables or figures not appearing
- **Solution:** Check that `output/tables/` and `output/figures/` directories exist (created by `0PathSetup.do`)

**Issue:** Path too long error on Windows
- **Solution:** Move the package to a shorter path (e.g., `C:\research\preventive-war`)

## Contact

For questions or issues with this replication package, please contact the authors.

## Version History

- **Version 1.0** (2025): Initial replication package release
- **Version 1.1** (2025): Simplified code structure with separate data cleaning and analysis files

## License

This replication package is provided for research and educational purposes. Experimental data and software remain the property of the authors.
