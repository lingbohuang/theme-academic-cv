*========================================
* Master Analysis File
*========================================
* This file runs all analysis for both experiments
* Run this file after 0PathSetup.do

display "========================================"
display "Starting Replication Analysis"
display "========================================"

*----------------------------------------
* Experiment 1
*----------------------------------------
display ""
display "----------------------------------------"
display "Experiment 1: Data Cleaning"
display "----------------------------------------"
do "$code_folder/stata/2clean_exp1.do"

display ""
display "----------------------------------------"
display "Experiment 1: Analysis"
display "----------------------------------------"
do "$code_folder/stata/3analysis_exp1.do"

*----------------------------------------
* Experiment 2
*----------------------------------------
display ""
display "----------------------------------------"
display "Experiment 2: Data Cleaning"
display "----------------------------------------"
do "$code_folder/stata/2clean_exp2.do"

display ""
display "----------------------------------------"
display "Experiment 2: Analysis"
display "----------------------------------------"
do "$code_folder/stata/3analysis_exp2.do"

display ""
display "========================================"
display "Analysis Complete!"
display "========================================"
display ""
display "Outputs saved to:"
display "  Tables: $tables_folder"
display "  Figures: $figures_folder"
display ""
display "Tables generated:"
display "  - Table 2: Estimated proportion of each type"
display "  - Table 3: Normative beliefs"
display "  - Table S2: Descriptive statistics (Exp 1)"
display "  - Table S3: Probit regression"
display "  - Table S4: Probit regression of avoiding the ask"
display "  - Table S5: Descriptive statistics (Exp 2)"
display ""
display "Figures generated:"
display "  - Figure 1a: Frequency of giving"
display "  - Figure 1b: Out-of-pocket giving"
display "  - Figure S3: Intensive margin"
display "  - Figure S4: Distribution of giving"
