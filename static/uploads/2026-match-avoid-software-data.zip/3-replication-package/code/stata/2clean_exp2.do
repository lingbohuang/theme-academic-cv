*========================================
* Data Cleaning - Experiment 2
*========================================
* Load raw data and create processed dataset

use "$exp2_raw", clear

* Approval questions (desirability) - first set
foreach num of numlist 1/7 {
    gen appro1`num' = 1 if d1`num' == "Extremely undesirable"
    replace appro1`num' = 2 if d1`num' == "Moderately undesirable"
    replace appro1`num' = 3 if d1`num' == "Slightly undesirable"
    replace appro1`num' = 4 if d1`num' == "Neither desirable nor undesirable"
    replace appro1`num' = 5 if d1`num' == "Slightly desirable"
    replace appro1`num' = 6 if d1`num' == "Moderately desirable"
    replace appro1`num' = 7 if d1`num' == "Extremely desirable"
}

foreach num of numlist 1/7 {
    gen approCutoff1`num' = 1 if appro1`num' < 4
    replace approCutoff1`num' = 0 if appro1`num' >= 4
}

* Approval questions (desirability) - second set
foreach num of numlist 1/7 {
    gen appro2`num' = 1 if d2`num' == "Extremely undesirable"
    replace appro2`num' = 2 if d2`num' == "Moderately undesirable"
    replace appro2`num' = 3 if d2`num' == "Slightly undesirable"
    replace appro2`num' = 4 if d2`num' == "Neither desirable nor undesirable"
    replace appro2`num' = 5 if d2`num' == "Slightly desirable"
    replace appro2`num' = 6 if d2`num' == "Moderately desirable"
    replace appro2`num' = 7 if d2`num' == "Extremely desirable"
}

foreach num of numlist 1/7 {
    gen approCutoff2`num' = 1 if appro2`num' < 4
    replace approCutoff2`num' = 0 if appro2`num' >= 4
}

* Norm questions - first set
foreach num of numlist 1/7 {
    gen norm1`num' = 1 if n1`num' == "Extremely undesirable"
    replace norm1`num' = 2 if n1`num' == "Moderately undesirable"
    replace norm1`num' = 3 if n1`num' == "Slightly undesirable"
    replace norm1`num' = 4 if n1`num' == "Neither desirable nor undesirable"
    replace norm1`num' = 5 if n1`num' == "Slightly desirable"
    replace norm1`num' = 6 if n1`num' == "Moderately desirable"
    replace norm1`num' = 7 if n1`num' == "Extremely desirable"
}

foreach num of numlist 1/7 {
    gen normCutoff1`num' = 1 if norm1`num' < 4
    replace normCutoff1`num' = 0 if norm1`num' >= 4
}

* Norm questions - second set
foreach num of numlist 1/7 {
    gen norm2`num' = 1 if n2`num' == "Extremely undesirable"
    replace norm2`num' = 2 if n2`num' == "Moderately undesirable"
    replace norm2`num' = 3 if n2`num' == "Slightly undesirable"
    replace norm2`num' = 4 if n2`num' == "Neither desirable nor undesirable"
    replace norm2`num' = 5 if n2`num' == "Slightly desirable"
    replace norm2`num' = 6 if n2`num' == "Moderately desirable"
    replace norm2`num' = 7 if n2`num' == "Extremely desirable"
}

foreach num of numlist 1/7 {
    gen normCutoff2`num' = 1 if norm2`num' < 4
    replace normCutoff2`num' = 0 if norm2`num' >= 4
}

* Government responsibility
gen govRes = 1 if govResp == "Strongly agree"
replace govRes = 2 if govResp == "Agree"
replace govRes = 3 if govResp == "Somewhat agree"
replace govRes = 4 if govResp == "Neither agree nor disagree"
replace govRes = 5 if govResp == "Somewhat disagree"
replace govRes = 6 if govResp == "Disagree"
replace govRes = 7 if govResp == "Strongly disagree"
gen govRes1 = (govRes < 4)

* Charity responsibility
gen charityRes = 1 if charityResp == "Strongly agree"
replace charityRes = 2 if charityResp == "Agree"
replace charityRes = 3 if charityResp == "Somewhat agree"
replace charityRes = 4 if charityResp == "Neither agree nor disagree"
replace charityRes = 5 if charityResp == "Somewhat disagree"
replace charityRes = 6 if charityResp == "Disagree"
replace charityRes = 7 if charityResp == "Strongly disagree"
gen charityRes1 = (charityRes < 4)

* Self responsibility
gen selfRes = 1 if selfResp == "Strongly agree"
replace selfRes = 2 if selfResp == "Agree"
replace selfRes = 3 if selfResp == "Somewhat agree"
replace selfRes = 4 if selfResp == "Neither agree nor disagree"
replace selfRes = 5 if selfResp == "Somewhat disagree"
replace selfRes = 6 if selfResp == "Disagree"
replace selfRes = 7 if selfResp == "Strongly disagree"
gen selfRes1 = (selfRes < 4)

* Frequency of donation
gen freqDon = 1 if freqDonation == "Not at all"
replace freqDon = 2 if freqDonation == "Once"
replace freqDon = 3 if freqDonation == "2 or 3 times"
replace freqDon = 4 if freqDonation == "4 or 5 times"
replace freqDon = 5 if freqDonation == "More than 5 times"
gen freqDon1 = (freqDon <= 2)

* Frequency of volunteering
gen freqVol = 1 if freqVolunteer == "Not at all"
replace freqVol = 2 if freqVolunteer == "Once"
replace freqVol = 3 if freqVolunteer == "2 or 3 times"
replace freqVol = 4 if freqVolunteer == "4 or 5 times"
replace freqVol = 5 if freqVolunteer == "More than 5 times"
gen freqVol1 = (freqVol <= 2)

* Demographics
gen female = (male == "Female")
gen age1 = real(age)

gen field = 1 if study == "Art, Design and Architecture"
replace field = 2 if study == "Business and Economics"
replace field = 3 if study == "Engineering"
replace field = 4 if study == "Law"
replace field = 5 if study == "Pharmacy and Pharmaceutical Sciences"
replace field = 6 if study == "Arts"
replace field = 7 if study == "Education"
replace field = 8 if study == "Information Technology"
replace field = 9 if study == "Medicine, Nursing and Health Sciences"
replace field = 10 if study == "Sciences"
gen econ = (field == 2)

gen yearStudy = 1 if year == "First Year"
replace yearStudy = 2 if year == "Second Year"
replace yearStudy = 3 if year == "Third Year"
replace yearStudy = 4 if year == "Fourth Year / Honours"
replace yearStudy = 5 if year == "Graduate Student"

gen ethnics = 1 if ethics == "Oceanian"
replace ethnics = 2 if ethics == "North-West European"
replace ethnics = 3 if ethics == "Southern and Eastern European"
replace ethnics = 4 if ethics == "North African and Middle Eastern"
replace ethnics = 5 if ethics == "South-East Asian"
replace ethnics = 6 if ethics == "North-East Asian"
replace ethnics = 7 if ethics == "Southern and Central Asian"
replace ethnics = 8 if ethics == "Peoples of the Americas"
replace ethnics = 9 if ethics == "Sub-Saharan African"
gen asian = (ethnics >= 5 & ethnics <= 7)

gen religions = 1 if religion == "Christian"
replace religions = 2 if religion == "Buddhist"
replace religions = 3 if religion == "Muslim"
replace religions = 4 if religion == "Jewish"
replace religions = 5 if religion == "Hindu"
replace religions = 6 if religion == "Other"
replace religions = 7 if religion == "None"
gen christian = (religions == 1)

gen politParty = 1 if party == "Greens"
replace politParty = 2 if party == "Labour"
replace politParty = 3 if party == "Liberal / National"
replace politParty = 4 if party == "Other"
gen liberal = (politParty == 3)

* Treatment variable
egen treat = group(avoid)

* Drop original string variables
drop d* n1* n2* govResp charityResp selfResp freqDonation freqVolunteer male age study year ethics religion party

* Save processed data
save "$exp2_processed", replace

display "Data cleaning complete: exp2_processed.dta saved"
